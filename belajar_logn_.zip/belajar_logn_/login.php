<?php
session_start();
if (isset($_SESSION['auth_id'])) {
    header("Location: http://{$_SERVER['HTTP_HOST']}");
    die();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="main.css"> 
    <style>
        body {
            background-image: url('valorant.jpg'); 
            background-size: cover;
            background-position: center;
            font-family: Arial, sans-serif;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .content {
            background-color: white;
            padding: 40px;
            border-radius: 10px;
            text-align: center;
            width: 500px;
            color: black;
            opacity: 0.8;
        }

        h1 {
            color: black;
            margin-bottom: 20px;
            font-family: inherit;
        }

        input[type=text], input[type=password] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: none;
            border-radius: 5px;
            background-color: rgb(238, 238, 238);
            color: black;
        }

        input[type=submit] {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #ff4655;
            color: white;
            font-size: 16px;
            cursor: pointer;
            margin-top: 20px;
        }

        input[type=submit]:hover {
            background-color: #d7444e;
        }

        .social-login-buttons {
            display: flex;
            justify-content: space-around;
            margin: 20px 0;
        }

        .social-login-buttons button {
            background-color: white;
            border: none;
            border-radius: 5px;
            padding: 10px;
            cursor: pointer;
        }

        .social-login-buttons button img {
            width: 24px;
            height: 24px;
        }

        .social-login-buttons button:hover {
            background-color: #ddd;
        }

        a {
            color: #ff4655;
            text-decoration: none;
            display: block;
            margin-top: 20px;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<div class="content">
        <h1>Login</h1>
        <form action="auth.php" method="POST">
            <div>
                <input type="text" name="username" placeholder="Username" required>
            </div>
            <div>
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <?php if (isset($_SESSION['error'])) : ?>
                <p style="color: red;"><?= $_SESSION['error'] ?></p>
            <?php
                unset($_SESSION['error']);
            endif;
            ?>
            <input type="submit" value="Login">
        </form>
        <div class="social-login-buttons">
            <button><img src="facebook.png" alt="Facebook"></button>
            <button><img src="google.png" alt="Google"></button>
            <button><img src="apple.png" alt="Apple"></button>
            <button><img src="xbox.png" alt="Xbox"></button>
            <button><img src="playstation.png" alt="PlayStation"></button>
        </div>
        <a href="/register.php">Don't have an account? Register</a>
    </div>
</body>

</html>
