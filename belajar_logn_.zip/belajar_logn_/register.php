<?php
require_once "koneksi.php";

if ($conn->connect_error) {
    die("Koneksi ke database gagal: " . $conn->connect_error);
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $sql = "INSERT INTO users (username, password) VALUES ('$username', '$password')";
    
    if ($conn->query($sql) === TRUE) {
        header("Location: login.php");
        echo "Registrasi berhasil untuk username: $username";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="main.css"> 
    <style>
        body {
            background-image: url('valorant.jpg');
            background-size: cover;
            font-family: Arial, sans-serif;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .content {
            background-color: rgba(0, 0, 0, 0.8);
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            width: 900px;
        }

        h1 {
            color: #ffcc00;
        }

        input[type=text], input[type=password] {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
            border: none;
            border-radius: 5px;
        }

        input[type=submit] {
            width: 95%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #ffcc00;
            color: black;
            font-size: 16px;
            cursor: pointer;
        }

        input[type=submit]:hover {
            background-color: #e6b800;
        }

        a {
            color: #ffcc00;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }        body {
            background-image: url('valorant.jpg'); 
            background-size: cover;
            background-position: center;
            font-family: Arial, sans-serif;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .content {
            background-color: white;
            padding: 40px;
            border-radius: 10px;
            text-align: center;
            width: 500px;
            color: black;
            opacity: 0.8;
        }

        h1 {
            color: black;
            margin-bottom: 20px;
            font-family: inherit;
        }

        input[type=text], input[type=password] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: none;
            border-radius: 5px;
            background-color: #333;
            color: black;
            background-color: rgb(238, 238, 238);
            text-decoration-color: black;
        }

        input[type=submit] {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #ff4655;
            color: white;
            font-size: 16px;
            cursor: pointer;
            margin-top: 20px;
        }

        input[type=submit]:hover {
            background-color: #d7444e;
        }

        .social-login-buttons {
            display: flex;
            justify-content: space-around;
            margin: 20px 0;
        }

        .social-login-buttons button {
            background-color: white;
            border: none;
            border-radius: 5px;
            padding: 10px;
            cursor: pointer;
        }

        .social-login-buttons button img {
            width: 24px;
            height: 24px;
        }

        .social-login-buttons button:hover {
            background-color: #ddd;
        }

        a {
            color: #ff4655;
            text-decoration: none;
            display: block;
            margin-top: 20px;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
<div class="content">
        <h1>Register</h1>
        <form method="post" action="">
            <div>
                <input type="text" name="username" placeholder="Username" required>
            </div>
            <div>
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <br>
            <input type="submit" value="Register">
            <br>
            <a href="/login.php">Already have an account? Login</a>
        </form>
    </div>
</body>

</html>
